import 'dart:ui';

import 'package:flutter/material.dart';

void main() {
  runApp(Myapp());
}

class Myapp extends StatelessWidget {
  //const ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("calculate application")),
        body: Home(),
      ),
    );
  }
}

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController quantity = TextEditingController();
  TextEditingController price = TextEditingController();
  TextEditingController result = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    result.text =
        ("by X Apples, Because each cost X THB, We have to pay X THB");
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Center(
        child: Column(
          children: [
            Image.asset(
              'assets/bird.png',
              width: 300,
            ),
            Text(
              "Calculator Program",
              style: TextStyle(fontSize: 30),
            ),
            TextField(
              controller: quantity,
              decoration: InputDecoration(
                  labelText: "Apple Amount", border: OutlineInputBorder()),
            ),
            SizedBox(
              height: 10,
            ),
            TextField(
              controller: price,
              decoration: InputDecoration(
                  labelText: "Apple Price", border: OutlineInputBorder()),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                var cal =
                    double.parse(quantity.text) * double.parse(price.text);
                print("Quanlity:${quantity.text}Total:${cal}THB");
                setState(() {
                  result.text =
                      "Buy ${quantity.text}Apples.Because each cost ${price.text} THB, We have to pay ${cal} THB";
                });
              },
              child: Text("Calculate"),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Color(0xffb74093)),
                padding: MaterialStateProperty.all(
                    EdgeInsets.fromLTRB(50, 20, 50, 20)),
                textStyle: MaterialStateProperty.all(TextStyle(fontSize: 30)),
              ),
            ),
            Text(result.text),
          ],
        ),
      ),
    );
  }
}
